import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon,
  Bell,
  Moon,
  Globe,
  Shield,
  Database,
  Sparkles
} from "lucide-react";

export default function Settings() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
          Configuración
        </h1>
        <p className="text-muted-foreground">
          Administra las preferencias de la plataforma
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-5 w-5 text-primary" />
              Configuración de IA
            </CardTitle>
            <CardDescription>
              Ajusta el comportamiento de las entrevistas con IA
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="strict-mode">Modo estricto</Label>
                <p className="text-sm text-muted-foreground">
                  Evaluaciones más rigurosas
                </p>
              </div>
              <Switch id="strict-mode" data-testid="switch-strict-mode" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="auto-analyze">Auto-análisis</Label>
                <p className="text-sm text-muted-foreground">
                  Analizar automáticamente al completar
                </p>
              </div>
              <Switch id="auto-analyze" defaultChecked data-testid="switch-auto-analyze" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="detailed-feedback">Feedback detallado</Label>
                <p className="text-sm text-muted-foreground">
                  Incluir análisis extendido
                </p>
              </div>
              <Switch id="detailed-feedback" defaultChecked data-testid="switch-detailed-feedback" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Bell className="h-5 w-5 text-primary" />
              Notificaciones
            </CardTitle>
            <CardDescription>
              Configura las alertas y notificaciones
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="new-candidate">Nuevos candidatos</Label>
                <p className="text-sm text-muted-foreground">
                  Notificar cuando se registren
                </p>
              </div>
              <Switch id="new-candidate" defaultChecked data-testid="switch-new-candidate" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="analysis-complete">Análisis completados</Label>
                <p className="text-sm text-muted-foreground">
                  Alertar cuando termine un análisis
                </p>
              </div>
              <Switch id="analysis-complete" defaultChecked data-testid="switch-analysis-complete" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="weekly-summary">Resumen semanal</Label>
                <p className="text-sm text-muted-foreground">
                  Enviar resumen por email
                </p>
              </div>
              <Switch id="weekly-summary" data-testid="switch-weekly-summary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Globe className="h-5 w-5 text-primary" />
              Preferencias Generales
            </CardTitle>
            <CardDescription>
              Idioma y personalización
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Idioma</Label>
                <p className="text-sm text-muted-foreground">
                  Español (México)
                </p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-change-language">
                Cambiar
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label>Zona horaria</Label>
                <p className="text-sm text-muted-foreground">
                  UTC-6 (Ciudad de México)
                </p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-change-timezone">
                Cambiar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Database className="h-5 w-5 text-primary" />
              Datos y Almacenamiento
            </CardTitle>
            <CardDescription>
              Gestión de información
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Exportar datos</Label>
                <p className="text-sm text-muted-foreground">
                  Descargar todos los análisis
                </p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-export-data">
                Exportar
              </Button>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label>Retención de datos</Label>
                <p className="text-sm text-muted-foreground">
                  90 días por defecto
                </p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-data-retention">
                Configurar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-5 w-5 text-primary" />
            Seguridad
          </CardTitle>
          <CardDescription>
            Opciones de seguridad y privacidad
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label>Autenticación de dos factores</Label>
              <p className="text-sm text-muted-foreground">
                Agrega una capa extra de seguridad a tu cuenta
              </p>
            </div>
            <Button variant="outline" data-testid="button-enable-2fa">
              Activar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
