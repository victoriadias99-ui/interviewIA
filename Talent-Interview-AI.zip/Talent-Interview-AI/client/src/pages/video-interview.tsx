import { useState, useRef, useEffect, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Phone, 
  PhoneOff,
  User,
  Bot,
  AlertCircle,
  CheckCircle2,
  Loader2
} from "lucide-react";
import type { Interview, Candidate } from "@shared/schema";

interface TranscriptEntry {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface FrameAnalysis {
  expression: string;
  confidence: number;
  eyeContact: boolean;
  posture: string;
}

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
}

export default function VideoInterview() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null) as { current: SpeechRecognition | null };
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  const [isCallActive, setIsCallActive] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [currentSpeech, setCurrentSpeech] = useState("");
  const [frameAnalyses, setFrameAnalyses] = useState<FrameAnalysis[]>([]);
  const [interviewComplete, setInterviewComplete] = useState(false);
  
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  const { data: interviewData, isLoading } = useQuery<{ 
    candidate: Candidate; 
    messages: Array<{ role: string; content: string }>;
  } & Interview>({
    queryKey: ["/api/interviews", id],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await fetch(`/api/video-interview/${id}/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      
      if (!response.ok) throw new Error("Failed to send message");
      
      const reader = response.body?.getReader();
      if (!reader) throw new Error("No reader available");
      
      let fullResponse = "";
      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.content) {
                fullResponse += data.content;
              }
              if (data.done) {
                return fullResponse;
              }
            } catch (e) {
              // Ignore parse errors
            }
          }
        }
      }
      
      return fullResponse;
    },
    onSuccess: (response) => {
      setTranscript(prev => [...prev, {
        role: "assistant",
        content: response,
        timestamp: new Date(),
      }]);
      speakText(response);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje",
        variant: "destructive",
      });
    },
  });

  const analyzeFrameMutation = useMutation({
    mutationFn: async (frameData: string) => {
      const response = await apiRequest("POST", `/api/video-interview/${id}/analyze-frame`, {
        frame: frameData,
      });
      return response.json();
    },
    onSuccess: (analysis: FrameAnalysis) => {
      setFrameAnalyses(prev => [...prev.slice(-9), analysis]);
    },
  });

  const completeInterviewMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/video-interview/${id}/complete`, {
        transcript: transcript.map(t => ({
          role: t.role,
          content: t.content,
        })),
        frameAnalyses,
      });
      return response.json();
    },
    onSuccess: () => {
      setInterviewComplete(true);
      queryClient.invalidateQueries({ queryKey: ["/api/interviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analyses"] });
      toast({
        title: "Entrevista completada",
        description: "El análisis se ha generado exitosamente",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo completar la entrevista",
        variant: "destructive",
      });
    },
  });

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: true,
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      return true;
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Error de cámara",
        description: "No se pudo acceder a la cámara o micrófono",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startSpeechRecognition = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore errors when stopping
      }
    }
    
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      toast({
        title: "No soportado",
        description: "Tu navegador no soporta reconocimiento de voz",
        variant: "destructive",
      });
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "es-ES";

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interimTranscript = "";
      let finalTranscript = "";

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcriptText = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcriptText;
        } else {
          interimTranscript += transcriptText;
        }
      }

      setCurrentSpeech(interimTranscript);

      if (finalTranscript) {
        setCurrentSpeech("");
        setTranscript(prev => [...prev, {
          role: "user",
          content: finalTranscript,
          timestamp: new Date(),
        }]);
        
        sendMessageMutation.mutate(finalTranscript);
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error("Speech recognition error:", event.error);
      if (event.error !== "no-speech" && event.error !== "aborted") {
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      // Auto-restart if call is still active and we should be listening
      if (recognitionRef.current === recognition) {
        try {
          recognition.start();
        } catch (e) {
          // Ignore start errors
        }
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
    } catch (e) {
      console.error("Failed to start speech recognition:", e);
    }
  }, [toast, sendMessageMutation]);

  const stopSpeechRecognition = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
  }, []);

  const speakText = useCallback((text: string) => {
    if (!("speechSynthesis" in window)) {
      toast({
        title: "No soportado",
        description: "Tu navegador no soporta síntesis de voz",
        variant: "destructive",
      });
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-ES";
    utterance.rate = 0.95;
    utterance.pitch = 1;

    const voices = window.speechSynthesis.getVoices();
    const spanishVoice = voices.find(v => v.lang.startsWith("es"));
    if (spanishVoice) {
      utterance.voice = spanishVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      // Stop recognition while AI is speaking
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
          recognitionRef.current = null;
        } catch (e) {
          // Ignore errors
        }
      }
      setIsListening(false);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      // Restart recognition after AI finishes speaking
      setTimeout(() => {
        startSpeechRecognition();
      }, 500);
    };

    synthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [toast, startSpeechRecognition]);

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;
    
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext("2d");
    
    if (!ctx) return null;
    
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    ctx.drawImage(video, 0, 0);
    
    return canvas.toDataURL("image/jpeg", 0.7);
  }, []);

  const startCall = async () => {
    const cameraStarted = await startCamera();
    if (!cameraStarted) return;
    
    setIsCallActive(true);
    
    setTimeout(() => {
      const greeting = `Hola ${interviewData?.candidate?.name || ""}. Soy tu entrevistador de inteligencia artificial. Voy a hacerte algunas preguntas para conocerte mejor. Por favor, responde con naturalidad y tómate el tiempo que necesites. ¿Estás listo para comenzar?`;
      
      setTranscript([{
        role: "assistant",
        content: greeting,
        timestamp: new Date(),
      }]);
      
      speakText(greeting);
    }, 1000);
  };

  const endCall = () => {
    stopSpeechRecognition();
    stopCamera();
    window.speechSynthesis.cancel();
    setIsCallActive(false);
    setIsSpeaking(false);
  };

  const toggleVideo = () => {
    if (streamRef.current) {
      const videoTrack = streamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoEnabled(videoTrack.enabled);
      }
    }
  };

  const toggleAudio = () => {
    if (streamRef.current) {
      const audioTrack = streamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsAudioEnabled(audioTrack.enabled);
      }
    }
  };

  useEffect(() => {
    let frameInterval: ReturnType<typeof setInterval> | null = null;
    
    const captureAndAnalyze = () => {
      if (!videoRef.current || !canvasRef.current) return;
      
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const ctx = canvas.getContext("2d");
      
      if (!ctx || video.videoWidth === 0) return;
      
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      ctx.drawImage(video, 0, 0);
      
      const frame = canvas.toDataURL("image/jpeg", 0.7);
      if (frame) {
        analyzeFrameMutation.mutate(frame);
      }
    };
    
    if (isCallActive && isVideoEnabled) {
      // Initial delay to let camera warm up
      const initialTimeout = setTimeout(() => {
        captureAndAnalyze();
        frameInterval = setInterval(captureAndAnalyze, 5000);
      }, 2000);
      
      return () => {
        clearTimeout(initialTimeout);
        if (frameInterval) clearInterval(frameInterval);
      };
    }
    
    return () => {
      if (frameInterval) clearInterval(frameInterval);
    };
  }, [isCallActive, isVideoEnabled]);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcript]);

  useEffect(() => {
    return () => {
      stopCamera();
      stopSpeechRecognition();
      window.speechSynthesis.cancel();
    };
  }, [stopCamera, stopSpeechRecognition]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const avgConfidence = frameAnalyses.length > 0
    ? Math.round(frameAnalyses.reduce((sum, a) => sum + a.confidence, 0) / frameAnalyses.length)
    : 0;

  const eyeContactPercent = frameAnalyses.length > 0
    ? Math.round((frameAnalyses.filter(a => a.eyeContact).length / frameAnalyses.length) * 100)
    : 0;

  return (
    <div className="h-full flex flex-col p-4 gap-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Entrevista por Video</h1>
          <p className="text-muted-foreground">
            {interviewData?.candidate?.name} - {interviewData?.type === "technical" ? "Técnica" : interviewData?.type === "cultural" ? "Cultural" : "General"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isCallActive ? (
            <Badge variant="default" className="bg-green-500">
              <span className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse" />
              En llamada
            </Badge>
          ) : (
            <Badge variant="secondary">Sin conexión</Badge>
          )}
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">
        <div className="lg:col-span-2 flex flex-col gap-4">
          <Card className="flex-1 flex flex-col min-h-0">
            <CardContent className="flex-1 p-4 flex flex-col gap-4">
              <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${!isVideoEnabled ? "hidden" : ""}`}
                  data-testid="video-preview"
                />
                {!isVideoEnabled && (
                  <div className="absolute inset-0 flex items-center justify-center bg-muted">
                    <div className="text-center">
                      <User className="h-16 w-16 mx-auto text-muted-foreground mb-2" />
                      <p className="text-muted-foreground">Cámara desactivada</p>
                    </div>
                  </div>
                )}
                
                {isSpeaking && (
                  <div className="absolute top-4 left-4 flex items-center gap-2 bg-background/80 backdrop-blur-sm px-3 py-1.5 rounded-full">
                    <Bot className="h-4 w-4 text-primary" />
                    <span className="text-sm">IA hablando...</span>
                  </div>
                )}
                
                {isListening && !isSpeaking && (
                  <div className="absolute top-4 left-4 flex items-center gap-2 bg-background/80 backdrop-blur-sm px-3 py-1.5 rounded-full">
                    <Mic className="h-4 w-4 text-green-500 animate-pulse" />
                    <span className="text-sm">Escuchando...</span>
                  </div>
                )}

                {currentSpeech && (
                  <div className="absolute bottom-4 left-4 right-4 bg-background/80 backdrop-blur-sm px-4 py-2 rounded-lg">
                    <p className="text-sm italic">{currentSpeech}</p>
                  </div>
                )}
              </div>
              
              <canvas ref={canvasRef} className="hidden" />

              <div className="flex items-center justify-center gap-4">
                <Button
                  size="icon"
                  variant={isVideoEnabled ? "outline" : "destructive"}
                  onClick={toggleVideo}
                  disabled={!isCallActive}
                  data-testid="button-toggle-video"
                >
                  {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
                </Button>
                
                <Button
                  size="icon"
                  variant={isAudioEnabled ? "outline" : "destructive"}
                  onClick={toggleAudio}
                  disabled={!isCallActive}
                  data-testid="button-toggle-audio"
                >
                  {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
                </Button>
                
                {!isCallActive ? (
                  <Button
                    size="lg"
                    className="bg-green-500 hover:bg-green-600"
                    onClick={startCall}
                    data-testid="button-start-call"
                  >
                    <Phone className="h-5 w-5 mr-2" />
                    Iniciar Entrevista
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    variant="destructive"
                    onClick={endCall}
                    data-testid="button-end-call"
                  >
                    <PhoneOff className="h-5 w-5 mr-2" />
                    Terminar Llamada
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col gap-4 min-h-0">
          <Card className="flex-1 flex flex-col min-h-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Transcripción</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 min-h-0">
              <ScrollArea className="h-[300px] pr-4">
                <div className="space-y-3">
                  {transcript.map((entry, index) => (
                    <div
                      key={index}
                      className={`flex gap-2 ${entry.role === "user" ? "justify-end" : ""}`}
                    >
                      {entry.role === "assistant" && (
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <Bot className="h-4 w-4 text-primary" />
                        </div>
                      )}
                      <div
                        className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                          entry.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                      >
                        {entry.content}
                      </div>
                      {entry.role === "user" && (
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                          <User className="h-4 w-4" />
                        </div>
                      )}
                    </div>
                  ))}
                  <div ref={transcriptEndRef} />
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Análisis en Tiempo Real</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Confianza</span>
                  <span>{avgConfidence}%</span>
                </div>
                <Progress value={avgConfidence} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Contacto Visual</span>
                  <span>{eyeContactPercent}%</span>
                </div>
                <Progress value={eyeContactPercent} className="h-2" />
              </div>

              {frameAnalyses.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-2">
                  <Badge variant="outline" className="text-xs">
                    {frameAnalyses[frameAnalyses.length - 1]?.expression || "Neutral"}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {frameAnalyses[frameAnalyses.length - 1]?.posture || "Normal"}
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {transcript.length >= 4 && !interviewComplete && (
            <Button
              className="w-full"
              onClick={() => completeInterviewMutation.mutate()}
              disabled={completeInterviewMutation.isPending}
              data-testid="button-complete-interview"
            >
              {completeInterviewMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <CheckCircle2 className="h-4 w-4 mr-2" />
              )}
              Finalizar y Analizar
            </Button>
          )}

          {interviewComplete && (
            <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
              <CardContent className="py-4 flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-900 dark:text-green-100">Análisis Completado</p>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-green-700 dark:text-green-300"
                    onClick={() => navigate("/reports")}
                  >
                    Ver Reporte
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}
