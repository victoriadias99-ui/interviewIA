import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { 
  Plus, 
  MessageSquare,
  Play,
  Clock,
  CheckCircle,
  XCircle,
  User
} from "lucide-react";
import type { Interview, Candidate, Position, InsertInterview } from "@shared/schema";

const statusLabels: Record<string, string> = {
  scheduled: "Programada",
  in_progress: "En Progreso",
  completed: "Completada",
  cancelled: "Cancelada",
};

const statusColors: Record<string, string> = {
  scheduled: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  in_progress: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  completed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  cancelled: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

const statusIcons: Record<string, React.ElementType> = {
  scheduled: Clock,
  in_progress: Play,
  completed: CheckCircle,
  cancelled: XCircle,
};

interface InterviewWithDetails extends Interview {
  candidate?: Candidate;
  position?: Position;
}

function InterviewCard({ 
  interview,
  candidate,
  position
}: { 
  interview: Interview;
  candidate?: Candidate;
  position?: Position;
}) {
  const StatusIcon = statusIcons[interview.status] || Clock;

  return (
    <Card className="group" data-testid={`card-interview-${interview.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              {candidate ? (
                <span className="text-primary font-medium">
                  {candidate.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                </span>
              ) : (
                <User className="h-6 w-6 text-primary" />
              )}
            </div>
            <div>
              <h3 className="font-semibold" data-testid={`text-interview-candidate-${interview.id}`}>
                {candidate?.name || "Candidato"}
              </h3>
              {position && (
                <p className="text-sm text-muted-foreground">
                  {position.title}
                </p>
              )}
            </div>
          </div>
          
          <Badge 
            variant="secondary" 
            className={statusColors[interview.status] || ""}
            data-testid={`badge-interview-status-${interview.id}`}
          >
            <StatusIcon className="mr-1 h-3 w-3" />
            {statusLabels[interview.status] || interview.status}
          </Badge>
        </div>

        <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <MessageSquare className="h-4 w-4" />
            <span>
              {interview.type === "ai_chat" ? "Entrevista IA" : "Video"}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>
              {new Date(interview.createdAt).toLocaleDateString('es-ES', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
              })}
            </span>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          {interview.status === "scheduled" || interview.status === "in_progress" ? (
            <Link href={`/interviews/${interview.id}`} className="flex-1">
              <Button className="w-full" data-testid={`button-start-interview-${interview.id}`}>
                <Play className="mr-2 h-4 w-4" />
                {interview.status === "in_progress" ? "Continuar" : "Iniciar"}
              </Button>
            </Link>
          ) : (
            <Link href={`/interviews/${interview.id}`} className="flex-1">
              <Button variant="outline" className="w-full" data-testid={`button-view-interview-${interview.id}`}>
                Ver Resultados
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function NewInterviewDialog({ 
  candidates,
  positions,
  onSuccess 
}: { 
  candidates: Candidate[];
  positions: Position[];
  onSuccess: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<string>("");
  const [selectedPosition, setSelectedPosition] = useState<string>("");
  const { toast } = useToast();

  const createMutation = useMutation({
    mutationFn: async (data: Partial<InsertInterview>) => {
      return apiRequest("POST", "/api/interviews", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setOpen(false);
      setSelectedCandidate("");
      setSelectedPosition("");
      toast({
        title: "Entrevista creada",
        description: "La entrevista ha sido programada exitosamente.",
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo crear la entrevista.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidate) {
      toast({
        title: "Candidato requerido",
        description: "Selecciona un candidato para la entrevista.",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate({
      candidateId: selectedCandidate,
      positionId: selectedPosition || undefined,
      type: "ai_chat",
      status: "scheduled",
    });
  };

  const availableCandidates = candidates.filter(
    c => c.status !== "hired" && c.status !== "rejected"
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-new-interview">
          <Plus className="mr-2 h-4 w-4" />
          Nueva Entrevista
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Programar Entrevista IA</DialogTitle>
          <DialogDescription>
            Selecciona un candidato para iniciar una entrevista con IA
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="candidate">Candidato *</Label>
            <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
              <SelectTrigger data-testid="select-interview-candidate">
                <SelectValue placeholder="Seleccionar candidato" />
              </SelectTrigger>
              <SelectContent>
                {availableCandidates.map((candidate) => (
                  <SelectItem key={candidate.id} value={candidate.id}>
                    {candidate.name} - {candidate.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="position">Posición (opcional)</Label>
            <Select value={selectedPosition} onValueChange={setSelectedPosition}>
              <SelectTrigger data-testid="select-interview-position">
                <SelectValue placeholder="Seleccionar posición" />
              </SelectTrigger>
              <SelectContent>
                {positions.filter(p => p.status === "open").map((position) => (
                  <SelectItem key={position.id} value={position.id}>
                    {position.title} - {position.department}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="rounded-md bg-muted p-4">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-8 w-8 text-primary" />
              <div>
                <p className="font-medium">Entrevista con IA</p>
                <p className="text-sm text-muted-foreground">
                  La IA realizará preguntas relevantes al candidato y evaluará sus respuestas
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={createMutation.isPending}
              data-testid="button-submit-interview"
            >
              {createMutation.isPending ? "Creando..." : "Programar Entrevista"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Interviews() {
  const { data: interviews, isLoading: loadingInterviews } = useQuery<Interview[]>({
    queryKey: ["/api/interviews"],
  });

  const { data: candidates } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
  });

  const { data: positions } = useQuery<Position[]>({
    queryKey: ["/api/positions"],
  });

  const getCandidate = (id: string) => candidates?.find(c => c.id === id);
  const getPosition = (id: string | null) => id ? positions?.find(p => p.id === id) : undefined;

  if (loadingInterviews) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-12 w-12 rounded-full mb-4" />
                <Skeleton className="h-5 w-32 mb-2" />
                <Skeleton className="h-4 w-48 mb-4" />
                <Skeleton className="h-10 w-full mt-4" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const activeInterviews = (interviews || []).filter(
    i => i.status === "scheduled" || i.status === "in_progress"
  );
  const completedInterviews = (interviews || []).filter(
    i => i.status === "completed"
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
            Entrevistas IA
          </h1>
          <p className="text-muted-foreground">
            Gestiona las entrevistas realizadas por la IA
          </p>
        </div>
        <NewInterviewDialog 
          candidates={candidates || []}
          positions={positions || []}
          onSuccess={() => {}}
        />
      </div>

      {activeInterviews.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Entrevistas Activas</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {activeInterviews.map((interview) => (
              <InterviewCard
                key={interview.id}
                interview={interview}
                candidate={getCandidate(interview.candidateId)}
                position={getPosition(interview.positionId)}
              />
            ))}
          </div>
        </div>
      )}

      {completedInterviews.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Entrevistas Completadas</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {completedInterviews.map((interview) => (
              <InterviewCard
                key={interview.id}
                interview={interview}
                candidate={getCandidate(interview.candidateId)}
                position={getPosition(interview.positionId)}
              />
            ))}
          </div>
        </div>
      )}

      {(!interviews || interviews.length === 0) && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <MessageSquare className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">No hay entrevistas</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Programa tu primera entrevista con IA para evaluar candidatos
              </p>
              {(candidates?.length || 0) > 0 ? (
                <NewInterviewDialog 
                  candidates={candidates || []}
                  positions={positions || []}
                  onSuccess={() => {}}
                />
              ) : (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground mb-2">
                    Primero necesitas agregar candidatos
                  </p>
                  <Link href="/candidates">
                    <Button data-testid="button-go-to-candidates">
                      Ir a Candidatos
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
