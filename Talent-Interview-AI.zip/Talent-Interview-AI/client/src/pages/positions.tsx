import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Plus, 
  Briefcase,
  Users,
  MoreVertical,
  Edit,
  Trash2,
  Building2
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Position, InsertPosition, Candidate } from "@shared/schema";

const statusLabels: Record<string, string> = {
  open: "Abierta",
  closed: "Cerrada",
  paused: "Pausada",
};

const statusColors: Record<string, string> = {
  open: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  closed: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
  paused: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
};

const departments = [
  "Ingeniería",
  "Diseño",
  "Marketing",
  "Ventas",
  "Recursos Humanos",
  "Finanzas",
  "Operaciones",
  "Producto",
  "Legal",
  "Otro"
];

function PositionCard({ 
  position, 
  candidateCount,
  onDelete,
  onEdit
}: { 
  position: Position;
  candidateCount: number;
  onDelete: (id: string) => void;
  onEdit: (position: Position) => void;
}) {
  return (
    <Card className="group" data-testid={`card-position-${position.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10">
              <Briefcase className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold" data-testid={`text-position-title-${position.id}`}>
                {position.title}
              </h3>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Building2 className="h-3 w-3" />
                <span>{position.department}</span>
              </div>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                data-testid={`button-position-menu-${position.id}`}
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem 
                onClick={() => onEdit(position)}
                data-testid={`button-edit-position-${position.id}`}
              >
                <Edit className="mr-2 h-4 w-4" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="text-destructive"
                onClick={() => onDelete(position.id)}
                data-testid={`button-delete-position-${position.id}`}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Eliminar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <p className="mt-4 text-sm text-muted-foreground line-clamp-2">
          {position.description}
        </p>

        <div className="mt-4 flex items-center justify-between gap-2">
          <Badge 
            variant="secondary" 
            className={statusColors[position.status] || ""}
            data-testid={`badge-status-${position.id}`}
          >
            {statusLabels[position.status] || position.status}
          </Badge>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{candidateCount} candidatos</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function PositionDialog({ 
  position,
  open,
  onOpenChange,
  onSuccess 
}: { 
  position?: Position;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}) {
  const [formData, setFormData] = useState<Partial<InsertPosition>>({
    title: position?.title || "",
    department: position?.department || "",
    description: position?.description || "",
    requirements: position?.requirements || "",
    status: position?.status || "open",
  });
  const { toast } = useToast();
  const isEdit = !!position;

  const mutation = useMutation({
    mutationFn: async (data: Partial<InsertPosition>) => {
      if (isEdit) {
        return apiRequest("PATCH", `/api/positions/${position.id}`, data);
      }
      return apiRequest("POST", "/api/positions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      onOpenChange(false);
      toast({
        title: isEdit ? "Posición actualizada" : "Posición creada",
        description: isEdit 
          ? "La posición ha sido actualizada exitosamente."
          : "La posición ha sido creada exitosamente.",
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Error",
        description: `No se pudo ${isEdit ? "actualizar" : "crear"} la posición.`,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.department || !formData.description) {
      toast({
        title: "Campos requeridos",
        description: "Título, departamento y descripción son obligatorios.",
        variant: "destructive",
      });
      return;
    }
    mutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Editar Posición" : "Nueva Posición"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Actualiza los datos de la posición" : "Ingresa los datos de la nueva posición"}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Título del puesto *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Desarrollador Senior"
                data-testid="input-position-title"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Departamento *</Label>
              <Select
                value={formData.department}
                onValueChange={(value) => setFormData({ ...formData, department: value })}
              >
                <SelectTrigger data-testid="select-position-department">
                  <SelectValue placeholder="Seleccionar departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Descripción *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe las responsabilidades del puesto..."
              rows={3}
              data-testid="input-position-description"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="requirements">Requisitos</Label>
            <Textarea
              id="requirements"
              value={formData.requirements}
              onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
              placeholder="Lista los requisitos y habilidades necesarias..."
              rows={3}
              data-testid="input-position-requirements"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="status">Estado</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData({ ...formData, status: value })}
            >
              <SelectTrigger data-testid="select-position-status">
                <SelectValue placeholder="Seleccionar estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="open">Abierta</SelectItem>
                <SelectItem value="paused">Pausada</SelectItem>
                <SelectItem value="closed">Cerrada</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={mutation.isPending}
              data-testid="button-submit-position"
            >
              {mutation.isPending ? "Guardando..." : (isEdit ? "Actualizar" : "Crear Posición")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Positions() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPosition, setEditingPosition] = useState<Position | undefined>();
  const { toast } = useToast();

  const { data: positions, isLoading } = useQuery<Position[]>({
    queryKey: ["/api/positions"],
  });

  const { data: candidates } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/positions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/positions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Posición eliminada",
        description: "La posición ha sido eliminada exitosamente.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo eliminar la posición.",
        variant: "destructive",
      });
    },
  });

  const getCandidateCount = (positionId: string) => {
    return (candidates || []).filter(c => c.positionId === positionId).length;
  };

  const handleEdit = (position: Position) => {
    setEditingPosition(position);
    setDialogOpen(true);
  };

  const handleDialogClose = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      setEditingPosition(undefined);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-12 w-12 rounded-md mb-4" />
                <Skeleton className="h-5 w-32 mb-2" />
                <Skeleton className="h-4 w-48 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-6 w-20 mt-4" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
            Posiciones
          </h1>
          <p className="text-muted-foreground">
            Gestiona las vacantes y puestos disponibles
          </p>
        </div>
        <Button onClick={() => setDialogOpen(true)} data-testid="button-add-position">
          <Plus className="mr-2 h-4 w-4" />
          Nueva Posición
        </Button>
      </div>

      {(positions?.length || 0) > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {positions?.map((position) => (
            <PositionCard
              key={position.id}
              position={position}
              candidateCount={getCandidateCount(position.id)}
              onDelete={(id) => deleteMutation.mutate(id)}
              onEdit={handleEdit}
            />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Briefcase className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">No hay posiciones</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Comienza creando tu primera posición para empezar a recibir candidatos
              </p>
              <Button 
                className="mt-4" 
                onClick={() => setDialogOpen(true)}
                data-testid="button-create-first-position"
              >
                <Plus className="mr-2 h-4 w-4" />
                Crear primera posición
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <PositionDialog
        position={editingPosition}
        open={dialogOpen}
        onOpenChange={handleDialogClose}
        onSuccess={() => {}}
      />
    </div>
  );
}
