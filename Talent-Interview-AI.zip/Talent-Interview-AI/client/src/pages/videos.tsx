import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Upload, 
  Video,
  FileVideo,
  Play,
  Clock,
  CheckCircle,
  Loader2,
  Sparkles,
  User,
  AlertCircle
} from "lucide-react";
import type { VideoAsset, Candidate, AnalysisResult } from "@shared/schema";

const statusLabels: Record<string, string> = {
  pending: "Pendiente",
  processing: "Procesando",
  analyzed: "Analizado",
  failed: "Error",
};

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  processing: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  analyzed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  failed: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

interface VideoWithDetails extends VideoAsset {
  candidate?: Candidate;
  analysis?: AnalysisResult;
}

function VideoCard({ 
  video, 
  candidate,
  onAnalyze 
}: { 
  video: VideoAsset;
  candidate?: Candidate;
  onAnalyze: (id: string) => void;
}) {
  return (
    <Card className="group" data-testid={`card-video-${video.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-muted">
              <FileVideo className="h-6 w-6 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-medium text-sm" data-testid={`text-video-name-${video.id}`}>
                {video.fileName}
              </h3>
              {candidate && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <User className="h-3 w-3" />
                  <span>{candidate.name}</span>
                </div>
              )}
            </div>
          </div>
          
          <Badge 
            variant="secondary" 
            className={statusColors[video.status] || ""}
            data-testid={`badge-video-status-${video.id}`}
          >
            {video.status === "processing" && (
              <Loader2 className="mr-1 h-3 w-3 animate-spin" />
            )}
            {statusLabels[video.status] || video.status}
          </Badge>
        </div>

        <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          <span>
            {new Date(video.createdAt).toLocaleDateString('es-ES', {
              day: 'numeric',
              month: 'short',
              year: 'numeric'
            })}
          </span>
        </div>

        {video.status === "pending" && (
          <Button 
            className="w-full mt-4"
            onClick={() => onAnalyze(video.id)}
            data-testid={`button-analyze-video-${video.id}`}
          >
            <Sparkles className="mr-2 h-4 w-4" />
            Analizar con IA
          </Button>
        )}

        {video.status === "analyzed" && (
          <Button 
            variant="outline"
            className="w-full mt-4"
            data-testid={`button-view-analysis-${video.id}`}
          >
            <Play className="mr-2 h-4 w-4" />
            Ver Análisis
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

function UploadVideoDialog({ 
  candidates,
  onSuccess 
}: { 
  candidates: Candidate[];
  onSuccess: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<string>("");
  const [fileName, setFileName] = useState("");
  const [transcript, setTranscript] = useState("");
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (data: { candidateId: string; fileName: string; transcript?: string }) => {
      return apiRequest("POST", "/api/videos", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setOpen(false);
      setSelectedCandidate("");
      setFileName("");
      setTranscript("");
      toast({
        title: "Video registrado",
        description: "El video ha sido agregado y está listo para análisis.",
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo registrar el video.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidate || !fileName) {
      toast({
        title: "Campos requeridos",
        description: "Selecciona un candidato y proporciona un nombre de archivo.",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate({
      candidateId: selectedCandidate,
      fileName,
      transcript: transcript || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-upload-video">
          <Upload className="mr-2 h-4 w-4" />
          Subir Video
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Registrar Video para Análisis</DialogTitle>
          <DialogDescription>
            Ingresa los datos del video del candidato para análisis con IA
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="candidate">Candidato *</Label>
            <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
              <SelectTrigger data-testid="select-video-candidate">
                <SelectValue placeholder="Seleccionar candidato" />
              </SelectTrigger>
              <SelectContent>
                {candidates.map((candidate) => (
                  <SelectItem key={candidate.id} value={candidate.id}>
                    {candidate.name} - {candidate.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fileName">Nombre del archivo *</Label>
            <div className="flex items-center gap-2">
              <FileVideo className="h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                id="fileName"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="entrevista_candidato.mp4"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                data-testid="input-video-filename"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="transcript">
              Transcripción del video (opcional)
              <span className="text-muted-foreground text-xs ml-2">
                Proporciona la transcripción para mejor análisis
              </span>
            </Label>
            <Textarea
              id="transcript"
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              placeholder="Pega aquí la transcripción del video del candidato..."
              rows={6}
              data-testid="input-video-transcript"
            />
          </div>

          <div className="rounded-md bg-muted p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="text-sm">
                <p className="font-medium">Nota sobre el análisis</p>
                <p className="text-muted-foreground mt-1">
                  La IA analizará la transcripción del video para evaluar al candidato. 
                  Para mejores resultados, proporciona una transcripción completa.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={uploadMutation.isPending}
              data-testid="button-submit-video"
            >
              {uploadMutation.isPending ? "Guardando..." : "Registrar Video"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Videos() {
  const { toast } = useToast();

  const { data: videos, isLoading: loadingVideos } = useQuery<VideoAsset[]>({
    queryKey: ["/api/videos"],
  });

  const { data: candidates } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
  });

  const analyzeMutation = useMutation({
    mutationFn: async (videoId: string) => {
      return apiRequest("POST", `/api/videos/${videoId}/analyze`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Análisis iniciado",
        description: "La IA está analizando el video del candidato.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo iniciar el análisis.",
        variant: "destructive",
      });
    },
  });

  const getCandidate = (id: string) => candidates?.find(c => c.id === id);

  if (loadingVideos) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-12 w-12 rounded-md mb-4" />
                <Skeleton className="h-5 w-32 mb-2" />
                <Skeleton className="h-4 w-48 mb-4" />
                <Skeleton className="h-10 w-full mt-4" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const pendingVideos = (videos || []).filter(v => v.status === "pending");
  const analyzedVideos = (videos || []).filter(v => v.status === "analyzed");

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
            Análisis de Videos
          </h1>
          <p className="text-muted-foreground">
            Sube videos de candidatos para análisis con IA
          </p>
        </div>
        <UploadVideoDialog 
          candidates={candidates || []}
          onSuccess={() => {}}
        />
      </div>

      {pendingVideos.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Pendientes de Análisis</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {pendingVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                candidate={getCandidate(video.candidateId)}
                onAnalyze={(id) => analyzeMutation.mutate(id)}
              />
            ))}
          </div>
        </div>
      )}

      {analyzedVideos.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Videos Analizados</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {analyzedVideos.map((video) => (
              <VideoCard
                key={video.id}
                video={video}
                candidate={getCandidate(video.candidateId)}
                onAnalyze={(id) => analyzeMutation.mutate(id)}
              />
            ))}
          </div>
        </div>
      )}

      {(!videos || videos.length === 0) && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Video className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">No hay videos</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                Sube videos de entrevistas de candidatos para que la IA los analice 
                y te proporcione feedback detallado
              </p>
              <UploadVideoDialog 
                candidates={candidates || []}
                onSuccess={() => {}}
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
