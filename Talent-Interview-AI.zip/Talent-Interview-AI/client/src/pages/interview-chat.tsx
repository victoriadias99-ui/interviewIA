import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Send, 
  ArrowLeft,
  Bot,
  User,
  CheckCircle,
  Loader2,
  Sparkles,
  Clock,
  Video
} from "lucide-react";
import type { Interview, Candidate, InterviewMessage, AnalysisResult } from "@shared/schema";

interface InterviewWithDetails extends Interview {
  candidate?: Candidate;
  messages?: InterviewMessage[];
  analysis?: AnalysisResult;
}

function MessageBubble({ message, isAI }: { message: InterviewMessage; isAI: boolean }) {
  return (
    <div className={`flex gap-3 ${isAI ? "" : "flex-row-reverse"}`}>
      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
        isAI ? "bg-primary text-primary-foreground" : "bg-muted"
      }`}>
        {isAI ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
      </div>
      <div className={`flex max-w-[80%] flex-col gap-1 ${isAI ? "" : "items-end"}`}>
        <div className={`rounded-lg px-4 py-2 ${
          isAI ? "bg-card border" : "bg-primary text-primary-foreground"
        }`}>
          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
        </div>
        <span className="text-xs text-muted-foreground">
          {new Date(message.createdAt).toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit'
          })}
        </span>
      </div>
    </div>
  );
}

function AnalysisPanel({ analysis }: { analysis: AnalysisResult }) {
  const getRecommendationColor = (rec: string) => {
    switch (rec) {
      case "strong_hire": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "hire": return "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300";
      case "maybe": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "no_hire": return "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300";
      case "strong_no_hire": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      default: return "";
    }
  };

  const recommendationLabels: Record<string, string> = {
    strong_hire: "Contratar (Altamente Recomendado)",
    hire: "Contratar",
    maybe: "Considerar",
    no_hire: "No Contratar",
    strong_no_hire: "No Contratar (Definitivo)",
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="h-4 w-4 text-primary" />
          Análisis de IA
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {analysis.recommendation && (
          <div>
            <p className="text-sm text-muted-foreground mb-2">Recomendación</p>
            <Badge 
              className={getRecommendationColor(analysis.recommendation)}
              data-testid="badge-recommendation"
            >
              {recommendationLabels[analysis.recommendation] || analysis.recommendation}
            </Badge>
          </div>
        )}

        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <span>Comunicación</span>
              <span className="font-medium">{analysis.communicationScore || 0}%</span>
            </div>
            <Progress value={analysis.communicationScore || 0} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <span>Técnico</span>
              <span className="font-medium">{analysis.technicalScore || 0}%</span>
            </div>
            <Progress value={analysis.technicalScore || 0} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <span>Fit Cultural</span>
              <span className="font-medium">{analysis.culturalFitScore || 0}%</span>
            </div>
            <Progress value={analysis.culturalFitScore || 0} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between text-sm mb-1">
              <span className="font-semibold">Puntuación General</span>
              <span className="font-bold text-primary">{analysis.overallScore || 0}%</span>
            </div>
            <Progress value={analysis.overallScore || 0} className="h-2" />
          </div>
        </div>

        {analysis.summary && (
          <div>
            <p className="text-sm text-muted-foreground mb-2">Resumen</p>
            <p className="text-sm">{analysis.summary}</p>
          </div>
        )}

        {analysis.strengths && analysis.strengths.length > 0 && (
          <div>
            <p className="text-sm text-muted-foreground mb-2">Fortalezas</p>
            <ul className="space-y-1">
              {analysis.strengths.map((s, i) => (
                <li key={i} className="text-sm flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {analysis.weaknesses && analysis.weaknesses.length > 0 && (
          <div>
            <p className="text-sm text-muted-foreground mb-2">Áreas de Mejora</p>
            <ul className="space-y-1">
              {analysis.weaknesses.map((w, i) => (
                <li key={i} className="text-sm flex items-start gap-2">
                  <Clock className="h-4 w-4 text-yellow-500 mt-0.5 shrink-0" />
                  <span>{w}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function InterviewChat() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: interview, isLoading } = useQuery<InterviewWithDetails>({
    queryKey: ["/api/interviews", id],
    enabled: !!id,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      setIsStreaming(true);
      setStreamingMessage("");

      const response = await fetch(`/api/interviews/${id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });

      if (!response.ok) {
        throw new Error("Failed to send message");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullMessage = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split("\n");

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.content) {
                  fullMessage += data.content;
                  setStreamingMessage(fullMessage);
                }
                if (data.done) {
                  setIsStreaming(false);
                }
              } catch (e) {
                // Ignore parse errors
              }
            }
          }
        }
      }

      return fullMessage;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interviews", id] });
      setInput("");
      setStreamingMessage("");
    },
    onError: () => {
      setIsStreaming(false);
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje.",
        variant: "destructive",
      });
    },
  });

  const completeInterviewMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/interviews/${id}/complete`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interviews", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/interviews"] });
      toast({
        title: "Entrevista completada",
        description: "El análisis del candidato está listo.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo completar la entrevista.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [interview?.messages, streamingMessage]);

  const handleSend = () => {
    if (!input.trim() || isStreaming) return;
    sendMessageMutation.mutate(input.trim());
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full">
        <div className="flex-1 flex flex-col">
          <div className="p-4 border-b">
            <Skeleton className="h-8 w-48" />
          </div>
          <div className="flex-1 p-4 space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className={`flex gap-3 ${i % 2 === 0 ? "" : "flex-row-reverse"}`}>
                <Skeleton className="h-8 w-8 rounded-full" />
                <Skeleton className="h-16 w-64" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!interview) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">Entrevista no encontrada</p>
        <Button 
          variant="outline" 
          className="mt-4"
          onClick={() => setLocation("/interviews")}
        >
          Volver a Entrevistas
        </Button>
      </div>
    );
  }

  const isCompleted = interview.status === "completed";
  const messages = interview.messages || [];

  return (
    <div className="flex h-full">
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-between gap-4 p-4 border-b">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/interviews")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              {interview.candidate ? (
                <span className="text-primary font-medium text-sm">
                  {interview.candidate.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                </span>
              ) : (
                <User className="h-5 w-5 text-primary" />
              )}
            </div>
            <div>
              <h1 className="font-semibold" data-testid="text-candidate-name">
                {interview.candidate?.name || "Candidato"}
              </h1>
              <p className="text-sm text-muted-foreground">
                Entrevista IA
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!isCompleted && (
              <Button 
                variant="outline"
                onClick={() => setLocation(`/interviews/${id}/video`)}
                data-testid="button-video-interview"
              >
                <Video className="mr-2 h-4 w-4" />
                Videollamada
              </Button>
            )}
            {!isCompleted && messages.length > 0 && (
              <Button 
                variant="outline"
                onClick={() => completeInterviewMutation.mutate()}
                disabled={completeInterviewMutation.isPending}
                data-testid="button-complete-interview"
              >
                {completeInterviewMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analizando...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Completar y Analizar
                  </>
                )}
              </Button>
            )}
            <Badge variant={isCompleted ? "secondary" : "default"}>
              {isCompleted ? "Completada" : "En Progreso"}
            </Badge>
          </div>
        </div>

        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4 max-w-3xl mx-auto">
            {messages.length === 0 && !isCompleted && (
              <div className="text-center py-8">
                <Bot className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <h3 className="mt-4 font-medium">Iniciar Entrevista</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Escribe un mensaje para comenzar la entrevista con la IA
                </p>
              </div>
            )}

            {messages.map((message) => (
              <MessageBubble 
                key={message.id} 
                message={message} 
                isAI={message.role === "assistant"} 
              />
            ))}

            {isStreaming && streamingMessage && (
              <div className="flex gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="flex max-w-[80%] flex-col gap-1">
                  <div className="rounded-lg px-4 py-2 bg-card border">
                    <p className="text-sm whitespace-pre-wrap">{streamingMessage}</p>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {!isCompleted && (
          <div className="p-4 border-t">
            <div className="flex gap-2 max-w-3xl mx-auto">
              <Textarea
                placeholder="Escribe tu mensaje..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isStreaming}
                className="min-h-[44px] max-h-32 resize-none"
                rows={1}
                data-testid="input-chat-message"
              />
              <Button 
                onClick={handleSend}
                disabled={!input.trim() || isStreaming}
                data-testid="button-send-message"
              >
                {isStreaming ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        )}
      </div>

      {interview.analysis && (
        <div className="w-80 border-l p-4 hidden lg:block">
          <AnalysisPanel analysis={interview.analysis} />
        </div>
      )}
    </div>
  );
}
