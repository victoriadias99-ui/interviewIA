import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { 
  BarChart3,
  TrendingUp,
  Users,
  CheckCircle,
  XCircle,
  Clock,
  ArrowRight,
  Sparkles,
  ThumbsUp,
  ThumbsDown,
  Minus
} from "lucide-react";
import type { AnalysisResult, Candidate } from "@shared/schema";

interface AnalysisWithCandidate extends AnalysisResult {
  candidate?: Candidate;
}

const recommendationLabels: Record<string, string> = {
  strong_hire: "Contratar (Altamente Recomendado)",
  hire: "Contratar",
  maybe: "Considerar",
  no_hire: "No Contratar",
  strong_no_hire: "No Contratar (Definitivo)",
};

const recommendationColors: Record<string, string> = {
  strong_hire: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  hire: "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300",
  maybe: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  no_hire: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300",
  strong_no_hire: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

const recommendationIcons: Record<string, React.ElementType> = {
  strong_hire: ThumbsUp,
  hire: ThumbsUp,
  maybe: Minus,
  no_hire: ThumbsDown,
  strong_no_hire: ThumbsDown,
};

function AnalysisCard({ analysis, candidate }: { analysis: AnalysisResult; candidate?: Candidate }) {
  const RecommendationIcon = recommendationIcons[analysis.recommendation || "maybe"] || Minus;

  return (
    <Card data-testid={`card-analysis-${analysis.id}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              {candidate ? (
                <span className="text-primary font-medium">
                  {candidate.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                </span>
              ) : (
                <Users className="h-6 w-6 text-primary" />
              )}
            </div>
            <div>
              <h3 className="font-semibold" data-testid={`text-analysis-candidate-${analysis.id}`}>
                {candidate?.name || "Candidato"}
              </h3>
              <p className="text-sm text-muted-foreground">
                {new Date(analysis.createdAt).toLocaleDateString('es-ES', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric'
                })}
              </p>
            </div>
          </div>
          
          {analysis.recommendation && (
            <Badge 
              variant="secondary" 
              className={recommendationColors[analysis.recommendation] || ""}
              data-testid={`badge-recommendation-${analysis.id}`}
            >
              <RecommendationIcon className="mr-1 h-3 w-3" />
              {recommendationLabels[analysis.recommendation] || analysis.recommendation}
            </Badge>
          )}
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span>Comunicación</span>
                <span className="font-medium">{analysis.communicationScore || 0}%</span>
              </div>
              <Progress value={analysis.communicationScore || 0} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span>Técnico</span>
                <span className="font-medium">{analysis.technicalScore || 0}%</span>
              </div>
              <Progress value={analysis.technicalScore || 0} className="h-2" />
            </div>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span>Fit Cultural</span>
                <span className="font-medium">{analysis.culturalFitScore || 0}%</span>
              </div>
              <Progress value={analysis.culturalFitScore || 0} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="font-semibold">General</span>
                <span className="font-bold text-primary">{analysis.overallScore || 0}%</span>
              </div>
              <Progress value={analysis.overallScore || 0} className="h-2" />
            </div>
          </div>
        </div>

        {analysis.summary && (
          <div className="mt-4">
            <p className="text-sm text-muted-foreground line-clamp-2">
              {analysis.summary}
            </p>
          </div>
        )}

        <div className="mt-4 flex items-center gap-4 flex-wrap">
          {analysis.strengths && analysis.strengths.length > 0 && (
            <div className="flex items-center gap-1 text-sm text-green-600">
              <CheckCircle className="h-4 w-4" />
              <span>{analysis.strengths.length} fortalezas</span>
            </div>
          )}
          {analysis.weaknesses && analysis.weaknesses.length > 0 && (
            <div className="flex items-center gap-1 text-sm text-yellow-600">
              <Clock className="h-4 w-4" />
              <span>{analysis.weaknesses.length} áreas de mejora</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Reports() {
  const { data: analyses, isLoading: loadingAnalyses } = useQuery<AnalysisWithCandidate[]>({
    queryKey: ["/api/analyses"],
  });

  const { data: candidates } = useQuery<Candidate[]>({
    queryKey: ["/api/candidates"],
  });

  const getCandidate = (id: string) => candidates?.find(c => c.id === id);

  // Calculate summary stats
  const totalAnalyses = analyses?.length || 0;
  const avgScore = analyses?.length 
    ? Math.round(analyses.reduce((sum, a) => sum + (a.overallScore || 0), 0) / analyses.length)
    : 0;
  const hireRecommendations = analyses?.filter(
    a => a.recommendation === "strong_hire" || a.recommendation === "hire"
  ).length || 0;
  const noHireRecommendations = analyses?.filter(
    a => a.recommendation === "strong_no_hire" || a.recommendation === "no_hire"
  ).length || 0;

  if (loadingAnalyses) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-12 w-12 rounded-full mb-4" />
                <Skeleton className="h-5 w-32 mb-2" />
                <Skeleton className="h-4 w-48" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
          Reportes y Análisis
        </h1>
        <p className="text-muted-foreground">
          Resumen de evaluaciones de IA para candidatos
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Análisis Totales
            </CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAnalyses}</div>
            <p className="text-xs text-muted-foreground mt-1">
              candidatos evaluados
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Puntuación Promedio
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgScore}%</div>
            <Progress value={avgScore} className="h-2 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Recomendados
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{hireRecommendations}</div>
            <p className="text-xs text-muted-foreground mt-1">
              para contratación
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              No Recomendados
            </CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{noHireRecommendations}</div>
            <p className="text-xs text-muted-foreground mt-1">
              candidatos
            </p>
          </CardContent>
        </Card>
      </div>

      {analyses && analyses.length > 0 ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Análisis Recientes</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {analyses.map((analysis) => (
              <AnalysisCard 
                key={analysis.id} 
                analysis={analysis} 
                candidate={getCandidate(analysis.candidateId)}
              />
            ))}
          </div>
        </div>
      ) : (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Sparkles className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">Sin análisis todavía</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                Los análisis aparecerán aquí cuando completes entrevistas con IA
                o analices videos de candidatos
              </p>
              <div className="mt-4 flex justify-center gap-2">
                <Link href="/interviews">
                  <Button variant="outline">
                    Ir a Entrevistas
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/videos">
                  <Button>
                    Subir Videos
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
