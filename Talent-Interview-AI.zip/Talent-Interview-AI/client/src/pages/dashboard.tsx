import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Users, 
  UserCheck, 
  MessageSquare, 
  TrendingUp, 
  Clock, 
  ArrowRight,
  Video,
  Calendar
} from "lucide-react";
import type { Candidate, Interview, Position } from "@shared/schema";

interface DashboardStats {
  totalCandidates: number;
  pendingReview: number;
  activeInterviews: number;
  hiredThisMonth: number;
  recentCandidates: Candidate[];
  upcomingInterviews: Interview[];
  openPositions: Position[];
}

function StatCard({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend 
}: { 
  title: string; 
  value: string | number; 
  description: string;
  icon: React.ElementType;
  trend?: { value: number; positive: boolean };
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground mt-1">
          {trend && (
            <span className={trend.positive ? "text-green-600" : "text-red-600"}>
              {trend.positive ? "+" : ""}{trend.value}%{" "}
            </span>
          )}
          {description}
        </p>
      </CardContent>
    </Card>
  );
}

function RecentCandidateRow({ candidate }: { candidate: Candidate }) {
  const statusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    screening: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    interviewing: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
    analyzed: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200",
    hired: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    rejected: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  };

  return (
    <div className="flex items-center justify-between gap-4 py-3 border-b last:border-0">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-medium">
          {candidate.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
        </div>
        <div>
          <p className="text-sm font-medium" data-testid={`text-candidate-name-${candidate.id}`}>
            {candidate.name}
          </p>
          <p className="text-xs text-muted-foreground">{candidate.email}</p>
        </div>
      </div>
      <Badge 
        variant="secondary" 
        className={statusColors[candidate.status] || ""}
        data-testid={`badge-status-${candidate.id}`}
      >
        {candidate.status}
      </Badge>
    </div>
  );
}

function UpcomingInterviewRow({ interview }: { interview: Interview & { candidateName?: string } }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3 border-b last:border-0">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
          {interview.type === "ai_chat" ? (
            <MessageSquare className="h-5 w-5 text-primary" />
          ) : (
            <Video className="h-5 w-5 text-primary" />
          )}
        </div>
        <div>
          <p className="text-sm font-medium">
            {interview.candidateName || "Candidato"}
          </p>
          <p className="text-xs text-muted-foreground">
            {interview.type === "ai_chat" ? "Entrevista IA" : "Video"}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Clock className="h-3 w-3" />
        {interview.scheduledAt 
          ? new Date(interview.scheduledAt).toLocaleDateString('es-ES', { 
              day: 'numeric', 
              month: 'short',
              hour: '2-digit',
              minute: '2-digit'
            })
          : "Sin programar"
        }
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-72" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const dashboardStats = stats || {
    totalCandidates: 0,
    pendingReview: 0,
    activeInterviews: 0,
    hiredThisMonth: 0,
    recentCandidates: [],
    upcomingInterviews: [],
    openPositions: [],
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
          Dashboard
        </h1>
        <p className="text-muted-foreground">
          Bienvenido a tu plataforma de entrevistas con IA
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Candidatos"
          value={dashboardStats.totalCandidates}
          description="en el sistema"
          icon={Users}
        />
        <StatCard
          title="Pendientes de Revisión"
          value={dashboardStats.pendingReview}
          description="necesitan análisis"
          icon={Clock}
          trend={{ value: 12, positive: false }}
        />
        <StatCard
          title="Entrevistas Activas"
          value={dashboardStats.activeInterviews}
          description="en progreso"
          icon={MessageSquare}
        />
        <StatCard
          title="Contratados"
          value={dashboardStats.hiredThisMonth}
          description="este mes"
          icon={UserCheck}
          trend={{ value: 8, positive: true }}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">Candidatos Recientes</CardTitle>
              <CardDescription>Últimos candidatos agregados al sistema</CardDescription>
            </div>
            <Link href="/candidates">
              <Button variant="ghost" size="sm" data-testid="button-view-all-candidates">
                Ver todos
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {dashboardStats.recentCandidates.length > 0 ? (
              dashboardStats.recentCandidates.slice(0, 5).map((candidate) => (
                <RecentCandidateRow key={candidate.id} candidate={candidate} />
              ))
            ) : (
              <div className="py-8 text-center">
                <Users className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-4 text-sm text-muted-foreground">
                  No hay candidatos aún
                </p>
                <Link href="/candidates">
                  <Button className="mt-4" size="sm" data-testid="button-add-first-candidate">
                    Agregar primer candidato
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">Próximas Entrevistas</CardTitle>
              <CardDescription>Entrevistas programadas</CardDescription>
            </div>
            <Link href="/interviews">
              <Button variant="ghost" size="sm" data-testid="button-view-all-interviews">
                Ver todas
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {dashboardStats.upcomingInterviews.length > 0 ? (
              dashboardStats.upcomingInterviews.slice(0, 5).map((interview) => (
                <UpcomingInterviewRow key={interview.id} interview={interview} />
              ))
            ) : (
              <div className="py-8 text-center">
                <Calendar className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <p className="mt-4 text-sm text-muted-foreground">
                  No hay entrevistas programadas
                </p>
                <Link href="/interviews">
                  <Button className="mt-4" size="sm" data-testid="button-schedule-interview">
                    Programar entrevista
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <div>
            <CardTitle className="text-base">Posiciones Abiertas</CardTitle>
            <CardDescription>Vacantes activas en búsqueda</CardDescription>
          </div>
          <Link href="/positions">
            <Button variant="ghost" size="sm" data-testid="button-view-all-positions">
              Ver todas
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {dashboardStats.openPositions.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {dashboardStats.openPositions.slice(0, 6).map((position) => (
                <div 
                  key={position.id} 
                  className="rounded-md border p-4 hover-elevate"
                  data-testid={`card-position-${position.id}`}
                >
                  <h3 className="font-medium">{position.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {position.department}
                  </p>
                  <Badge variant="secondary" className="mt-3">
                    {position.status}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center">
              <TrendingUp className="mx-auto h-12 w-12 text-muted-foreground/50" />
              <p className="mt-4 text-sm text-muted-foreground">
                No hay posiciones abiertas
              </p>
              <Link href="/positions">
                <Button className="mt-4" size="sm" data-testid="button-create-position">
                  Crear posición
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
