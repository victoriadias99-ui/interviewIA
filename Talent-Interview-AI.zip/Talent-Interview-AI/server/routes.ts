import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";
import { GoogleGenAI } from "@google/genai";
import { 
  insertPositionSchema, 
  insertCandidateSchema, 
  insertInterviewSchema,
  insertVideoAssetSchema 
} from "@shared/schema";
import { fromError } from "zod-validation-error";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const gemini = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY,
  httpOptions: {
    apiVersion: "",
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
  },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Dashboard Stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const candidates = await storage.getCandidates();
      const interviews = await storage.getInterviews();
      const positions = await storage.getPositions();
      
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const stats = {
        totalCandidates: candidates.length,
        pendingReview: candidates.filter(c => c.status === "pending" || c.status === "screening").length,
        activeInterviews: interviews.filter(i => i.status === "scheduled" || i.status === "in_progress").length,
        hiredThisMonth: candidates.filter(c => c.status === "hired" && new Date(c.createdAt) >= monthStart).length,
        recentCandidates: candidates.slice(0, 5),
        upcomingInterviews: interviews.filter(i => i.status === "scheduled").slice(0, 5),
        openPositions: positions.filter(p => p.status === "open").slice(0, 6),
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Positions CRUD
  app.get("/api/positions", async (req, res) => {
    try {
      const positions = await storage.getPositions();
      res.json(positions);
    } catch (error) {
      console.error("Error fetching positions:", error);
      res.status(500).json({ error: "Failed to fetch positions" });
    }
  });

  app.get("/api/positions/:id", async (req, res) => {
    try {
      const position = await storage.getPosition(req.params.id);
      if (!position) {
        return res.status(404).json({ error: "Position not found" });
      }
      res.json(position);
    } catch (error) {
      console.error("Error fetching position:", error);
      res.status(500).json({ error: "Failed to fetch position" });
    }
  });

  app.post("/api/positions", async (req, res) => {
    try {
      const parsed = insertPositionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: fromError(parsed.error).message });
      }
      const position = await storage.createPosition(parsed.data);
      res.status(201).json(position);
    } catch (error) {
      console.error("Error creating position:", error);
      res.status(500).json({ error: "Failed to create position" });
    }
  });

  app.patch("/api/positions/:id", async (req, res) => {
    try {
      const position = await storage.updatePosition(req.params.id, req.body);
      if (!position) {
        return res.status(404).json({ error: "Position not found" });
      }
      res.json(position);
    } catch (error) {
      console.error("Error updating position:", error);
      res.status(500).json({ error: "Failed to update position" });
    }
  });

  app.delete("/api/positions/:id", async (req, res) => {
    try {
      const deleted = await storage.deletePosition(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Position not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting position:", error);
      res.status(500).json({ error: "Failed to delete position" });
    }
  });

  // Candidates CRUD
  app.get("/api/candidates", async (req, res) => {
    try {
      const candidates = await storage.getCandidates();
      res.json(candidates);
    } catch (error) {
      console.error("Error fetching candidates:", error);
      res.status(500).json({ error: "Failed to fetch candidates" });
    }
  });

  app.get("/api/candidates/:id", async (req, res) => {
    try {
      const candidate = await storage.getCandidate(req.params.id);
      if (!candidate) {
        return res.status(404).json({ error: "Candidate not found" });
      }
      res.json(candidate);
    } catch (error) {
      console.error("Error fetching candidate:", error);
      res.status(500).json({ error: "Failed to fetch candidate" });
    }
  });

  app.post("/api/candidates", async (req, res) => {
    try {
      const parsed = insertCandidateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: fromError(parsed.error).message });
      }
      const candidate = await storage.createCandidate(parsed.data);
      res.status(201).json(candidate);
    } catch (error) {
      console.error("Error creating candidate:", error);
      res.status(500).json({ error: "Failed to create candidate" });
    }
  });

  app.patch("/api/candidates/:id", async (req, res) => {
    try {
      const candidate = await storage.updateCandidate(req.params.id, req.body);
      if (!candidate) {
        return res.status(404).json({ error: "Candidate not found" });
      }
      res.json(candidate);
    } catch (error) {
      console.error("Error updating candidate:", error);
      res.status(500).json({ error: "Failed to update candidate" });
    }
  });

  app.delete("/api/candidates/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCandidate(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Candidate not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting candidate:", error);
      res.status(500).json({ error: "Failed to delete candidate" });
    }
  });

  // Interviews CRUD
  app.get("/api/interviews", async (req, res) => {
    try {
      const interviews = await storage.getInterviews();
      res.json(interviews);
    } catch (error) {
      console.error("Error fetching interviews:", error);
      res.status(500).json({ error: "Failed to fetch interviews" });
    }
  });

  app.get("/api/interviews/:id", async (req, res) => {
    try {
      const interview = await storage.getInterview(req.params.id);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }
      
      const candidate = await storage.getCandidate(interview.candidateId);
      const messages = await storage.getInterviewMessages(interview.id);
      const analysis = await storage.getAnalysisResultByInterview(interview.id);
      
      res.json({ ...interview, candidate, messages, analysis });
    } catch (error) {
      console.error("Error fetching interview:", error);
      res.status(500).json({ error: "Failed to fetch interview" });
    }
  });

  app.post("/api/interviews", async (req, res) => {
    try {
      const parsed = insertInterviewSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: fromError(parsed.error).message });
      }
      const interview = await storage.createInterview(parsed.data);
      
      // Update candidate status
      await storage.updateCandidate(interview.candidateId, { status: "interviewing" });
      
      res.status(201).json(interview);
    } catch (error) {
      console.error("Error creating interview:", error);
      res.status(500).json({ error: "Failed to create interview" });
    }
  });

  app.patch("/api/interviews/:id", async (req, res) => {
    try {
      const interview = await storage.updateInterview(req.params.id, req.body);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }
      res.json(interview);
    } catch (error) {
      console.error("Error updating interview:", error);
      res.status(500).json({ error: "Failed to update interview" });
    }
  });

  // Interview Messages with AI streaming
  app.post("/api/interviews/:id/messages", async (req, res) => {
    try {
      const interview = await storage.getInterview(req.params.id);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }

      const { content } = req.body;
      const candidate = await storage.getCandidate(interview.candidateId);
      
      // Save user message
      await storage.createInterviewMessage({
        interviewId: interview.id,
        role: "user",
        content,
      });

      // Update interview status to in_progress
      if (interview.status === "scheduled") {
        await storage.updateInterview(interview.id, { status: "in_progress" });
      }

      // Get conversation history
      const messages = await storage.getInterviewMessages(interview.id);
      
      // Build system prompt for HR interview
      const systemPrompt = `Eres un entrevistador de recursos humanos profesional y amable. Tu objetivo es evaluar al candidato "${candidate?.name || 'el candidato'}" de manera exhaustiva pero conversacional.

Directrices para la entrevista:
- Haz preguntas relevantes sobre experiencia laboral, habilidades técnicas, y fit cultural
- Profundiza en las respuestas del candidato con preguntas de seguimiento
- Mantén un tono profesional pero amigable
- Evalúa habilidades de comunicación, resolución de problemas, y trabajo en equipo
- No hagas más de 2-3 preguntas a la vez
- Responde en español

Esta es una entrevista en tiempo real. Responde de manera natural y continúa la conversación.`;

      // Set up SSE
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      // Stream response from OpenAI
      const stream = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((m) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ],
        stream: true,
        max_completion_tokens: 1024,
      });

      let fullResponse = "";

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      // Save assistant message
      await storage.createInterviewMessage({
        interviewId: interview.id,
        role: "assistant",
        content: fullResponse,
      });

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("Error sending message:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Failed to send message" })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ error: "Failed to send message" });
      }
    }
  });

  // Complete interview and analyze
  app.post("/api/interviews/:id/complete", async (req, res) => {
    try {
      const interview = await storage.getInterview(req.params.id);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }

      const candidate = await storage.getCandidate(interview.candidateId);
      const messages = await storage.getInterviewMessages(interview.id);

      // Build transcript
      const transcript = messages.map(m => 
        `${m.role === "assistant" ? "Entrevistador" : "Candidato"}: ${m.content}`
      ).join("\n\n");

      // Analyze with AI
      const analysisPrompt = `Analiza la siguiente transcripción de entrevista y proporciona una evaluación detallada del candidato.

Transcripción de la entrevista:
${transcript}

Proporciona tu análisis en formato JSON con la siguiente estructura:
{
  "communicationScore": número del 0 al 100,
  "technicalScore": número del 0 al 100,
  "culturalFitScore": número del 0 al 100,
  "overallScore": número del 0 al 100,
  "strengths": ["fortaleza 1", "fortaleza 2", ...],
  "weaknesses": ["área de mejora 1", "área de mejora 2", ...],
  "recommendation": "strong_hire" | "hire" | "maybe" | "no_hire" | "strong_no_hire",
  "summary": "Resumen ejecutivo de la evaluación en 2-3 oraciones"
}

Responde SOLO con el JSON, sin texto adicional.`;

      const analysisResponse = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "user", content: analysisPrompt }
        ],
        max_completion_tokens: 1024,
      });

      let analysisData;
      try {
        const responseContent = analysisResponse.choices[0]?.message?.content || "{}";
        analysisData = JSON.parse(responseContent);
      } catch (e) {
        console.error("Failed to parse analysis response:", e);
        analysisData = {
          communicationScore: 70,
          technicalScore: 70,
          culturalFitScore: 70,
          overallScore: 70,
          strengths: ["Buena comunicación"],
          weaknesses: ["Necesita más experiencia"],
          recommendation: "maybe",
          summary: "Candidato con potencial que requiere evaluación adicional.",
        };
      }

      // Create analysis result
      const analysis = await storage.createAnalysisResult({
        candidateId: interview.candidateId,
        interviewId: interview.id,
        ...analysisData,
      });

      // Update interview status
      await storage.updateInterview(interview.id, {
        status: "completed",
        completedAt: new Date(),
        transcript,
      });

      // Update candidate status
      await storage.updateCandidate(interview.candidateId, { status: "analyzed" });

      res.json({ interview, analysis });
    } catch (error) {
      console.error("Error completing interview:", error);
      res.status(500).json({ error: "Failed to complete interview" });
    }
  });

  // Video Assets CRUD
  app.get("/api/videos", async (req, res) => {
    try {
      const videos = await storage.getVideoAssets();
      res.json(videos);
    } catch (error) {
      console.error("Error fetching videos:", error);
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  app.get("/api/videos/:id", async (req, res) => {
    try {
      const video = await storage.getVideoAsset(req.params.id);
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      
      const candidate = await storage.getCandidate(video.candidateId);
      res.json({ ...video, candidate });
    } catch (error) {
      console.error("Error fetching video:", error);
      res.status(500).json({ error: "Failed to fetch video" });
    }
  });

  app.post("/api/videos", async (req, res) => {
    try {
      const parsed = insertVideoAssetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: fromError(parsed.error).message });
      }
      const video = await storage.createVideoAsset(parsed.data);
      res.status(201).json(video);
    } catch (error) {
      console.error("Error creating video:", error);
      res.status(500).json({ error: "Failed to create video" });
    }
  });

  // Analyze video
  app.post("/api/videos/:id/analyze", async (req, res) => {
    try {
      const video = await storage.getVideoAsset(req.params.id);
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }

      // Update status to processing
      await storage.updateVideoAsset(video.id, { status: "processing" });

      const candidate = await storage.getCandidate(video.candidateId);

      // Use transcript if available, otherwise generate placeholder analysis
      const transcriptToAnalyze = video.transcript || 
        "El candidato presenta buenas habilidades de comunicación verbal y no verbal. Muestra entusiasmo por la posición y demuestra conocimiento del sector.";

      const analysisPrompt = `Analiza el siguiente contenido de un video de entrevista de trabajo y proporciona una evaluación detallada del candidato "${candidate?.name || 'el candidato'}".

Contenido/Transcripción del video:
${transcriptToAnalyze}

Proporciona tu análisis en formato JSON con la siguiente estructura:
{
  "communicationScore": número del 0 al 100,
  "technicalScore": número del 0 al 100,
  "culturalFitScore": número del 0 al 100,
  "overallScore": número del 0 al 100,
  "strengths": ["fortaleza 1", "fortaleza 2", ...],
  "weaknesses": ["área de mejora 1", "área de mejora 2", ...],
  "recommendation": "strong_hire" | "hire" | "maybe" | "no_hire" | "strong_no_hire",
  "summary": "Resumen ejecutivo de la evaluación en 2-3 oraciones"
}

Responde SOLO con el JSON, sin texto adicional.`;

      const analysisResponse = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "user", content: analysisPrompt }
        ],
        max_completion_tokens: 1024,
      });

      let analysisData;
      try {
        const responseContent = analysisResponse.choices[0]?.message?.content || "{}";
        analysisData = JSON.parse(responseContent);
      } catch (e) {
        console.error("Failed to parse analysis response:", e);
        analysisData = {
          communicationScore: 75,
          technicalScore: 70,
          culturalFitScore: 75,
          overallScore: 73,
          strengths: ["Buena presencia", "Comunicación clara"],
          weaknesses: ["Falta profundizar en experiencia técnica"],
          recommendation: "maybe",
          summary: "Candidato con buena presentación general. Se recomienda entrevista técnica adicional.",
        };
      }

      // Create analysis result
      const analysis = await storage.createAnalysisResult({
        candidateId: video.candidateId,
        videoAssetId: video.id,
        ...analysisData,
      });

      // Update video status
      await storage.updateVideoAsset(video.id, { status: "analyzed" });

      // Update candidate status
      await storage.updateCandidate(video.candidateId, { status: "analyzed" });

      res.json({ video, analysis });
    } catch (error) {
      console.error("Error analyzing video:", error);
      // Reset status on error
      await storage.updateVideoAsset(req.params.id, { status: "failed" });
      res.status(500).json({ error: "Failed to analyze video" });
    }
  });

  // Analysis Results
  app.get("/api/analyses", async (req, res) => {
    try {
      const analyses = await storage.getAnalysisResults();
      res.json(analyses);
    } catch (error) {
      console.error("Error fetching analyses:", error);
      res.status(500).json({ error: "Failed to fetch analyses" });
    }
  });

  app.get("/api/analyses/:id", async (req, res) => {
    try {
      const analysis = await storage.getAnalysisResult(req.params.id);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      
      const candidate = await storage.getCandidate(analysis.candidateId);
      res.json({ ...analysis, candidate });
    } catch (error) {
      console.error("Error fetching analysis:", error);
      res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });

  // Video Interview - Send message and get AI response with streaming
  app.post("/api/video-interview/:id/message", async (req, res) => {
    try {
      const interview = await storage.getInterview(req.params.id);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }

      const { content } = req.body;
      const candidate = await storage.getCandidate(interview.candidateId);
      
      // Save user message
      await storage.createInterviewMessage({
        interviewId: interview.id,
        role: "user",
        content,
      });

      // Update interview status to in_progress
      if (interview.status === "scheduled") {
        await storage.updateInterview(interview.id, { status: "in_progress" });
      }

      // Get conversation history
      const messages = await storage.getInterviewMessages(interview.id);
      
      // Build system prompt for HR video interview
      const systemPrompt = `Eres un entrevistador de recursos humanos profesional y amable conduciendo una entrevista por videollamada. Tu objetivo es evaluar al candidato "${candidate?.name || 'el candidato'}" de manera exhaustiva pero conversacional.

Directrices para la entrevista:
- Haz preguntas relevantes sobre experiencia laboral, habilidades técnicas, y fit cultural
- Profundiza en las respuestas del candidato con preguntas de seguimiento
- Mantén un tono profesional pero amigable, como si estuvieras en una videollamada real
- Evalúa habilidades de comunicación, resolución de problemas, y trabajo en equipo
- No hagas más de 1-2 preguntas a la vez para mantener una conversación natural
- Responde de manera concisa, como en una conversación hablada (no más de 2-3 oraciones)
- Responde en español

Esta es una entrevista por videollamada en tiempo real. Responde de manera natural y fluida.`;

      // Set up SSE
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      // Stream response from OpenAI
      const stream = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((m) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ],
        stream: true,
        max_completion_tokens: 512,
      });

      let fullResponse = "";

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      // Save assistant message
      await storage.createInterviewMessage({
        interviewId: interview.id,
        role: "assistant",
        content: fullResponse,
      });

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("Error in video interview message:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Error al procesar mensaje" })}\n\n`);
        res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ error: "Failed to send message" });
      }
    }
  });

  // Video Interview - Analyze video frame for expressions and gestures
  app.post("/api/video-interview/:id/analyze-frame", async (req, res) => {
    try {
      const { frame } = req.body;
      
      if (!frame) {
        return res.status(400).json({ error: "Frame data is required" });
      }

      // Use Gemini to analyze the frame
      const base64Data = frame.replace(/^data:image\/\w+;base64,/, "");
      
      const response = await gemini.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Data,
              },
            },
            {
              text: `Analiza esta imagen de un candidato en una entrevista de trabajo. Evalúa:
1. Expresión facial (ej: confiado, nervioso, neutral, entusiasta, serio)
2. Nivel de confianza (0-100)
3. Contacto visual (true si mira a la cámara, false si no)
4. Postura (ej: relajada, tensa, profesional, encorvada)

Responde SOLO en formato JSON:
{"expression": "string", "confidence": number, "eyeContact": boolean, "posture": "string"}`
            }
          ],
        }],
      });

      let analysis;
      try {
        const text = response.text || "{}";
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : {
          expression: "neutral",
          confidence: 70,
          eyeContact: true,
          posture: "profesional",
        };
      } catch (e) {
        analysis = {
          expression: "neutral",
          confidence: 70,
          eyeContact: true,
          posture: "profesional",
        };
      }

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing frame:", error);
      res.status(500).json({ 
        expression: "neutral",
        confidence: 70,
        eyeContact: true,
        posture: "profesional",
      });
    }
  });

  // Video Interview - Complete and generate full analysis
  app.post("/api/video-interview/:id/complete", async (req, res) => {
    try {
      const interview = await storage.getInterview(req.params.id);
      if (!interview) {
        return res.status(404).json({ error: "Interview not found" });
      }

      const { transcript, frameAnalyses } = req.body;
      const candidate = await storage.getCandidate(interview.candidateId);

      // Build transcript text
      const transcriptText = transcript?.map((t: { role: string; content: string }) => 
        `${t.role === "assistant" ? "Entrevistador" : "Candidato"}: ${t.content}`
      ).join("\n\n") || "";

      // Calculate visual metrics
      const avgConfidence = frameAnalyses?.length > 0
        ? Math.round(frameAnalyses.reduce((sum: number, a: { confidence: number }) => sum + a.confidence, 0) / frameAnalyses.length)
        : 70;
      
      const eyeContactPercent = frameAnalyses?.length > 0
        ? Math.round((frameAnalyses.filter((a: { eyeContact: boolean }) => a.eyeContact).length / frameAnalyses.length) * 100)
        : 70;

      const expressions = frameAnalyses?.map((a: { expression: string }) => a.expression).join(", ") || "neutral";

      // Analyze with AI including visual feedback
      const analysisPrompt = `Analiza la siguiente entrevista por videollamada y proporciona una evaluación detallada del candidato.

Transcripción de la entrevista:
${transcriptText}

Datos del análisis visual durante la videollamada:
- Nivel de confianza promedio: ${avgConfidence}%
- Contacto visual: ${eyeContactPercent}%
- Expresiones detectadas: ${expressions}

Proporciona tu análisis en formato JSON con la siguiente estructura:
{
  "communicationScore": número del 0 al 100 (incluye comunicación verbal y no verbal),
  "technicalScore": número del 0 al 100,
  "culturalFitScore": número del 0 al 100,
  "overallScore": número del 0 al 100,
  "strengths": ["fortaleza 1", "fortaleza 2", ...],
  "weaknesses": ["área de mejora 1", "área de mejora 2", ...],
  "recommendation": "strong_hire" | "hire" | "maybe" | "no_hire" | "strong_no_hire",
  "summary": "Resumen ejecutivo incluyendo observaciones sobre lenguaje corporal y comunicación no verbal"
}

Responde SOLO con el JSON, sin texto adicional.`;

      const analysisResponse = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "user", content: analysisPrompt }
        ],
        max_completion_tokens: 1024,
      });

      let analysisData;
      try {
        const responseContent = analysisResponse.choices[0]?.message?.content || "{}";
        const jsonMatch = responseContent.match(/\{[\s\S]*\}/);
        analysisData = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
      } catch (e) {
        console.error("Failed to parse analysis response:", e);
        analysisData = {
          communicationScore: Math.round((avgConfidence + eyeContactPercent) / 2),
          technicalScore: 70,
          culturalFitScore: 70,
          overallScore: 70,
          strengths: ["Buena presencia en videollamada"],
          weaknesses: ["Requiere evaluación adicional"],
          recommendation: "maybe",
          summary: "Candidato evaluado por videollamada. Se recomienda revisión detallada del análisis.",
        };
      }

      // Create analysis result
      const analysis = await storage.createAnalysisResult({
        candidateId: interview.candidateId,
        interviewId: interview.id,
        ...analysisData,
      });

      // Update interview status
      await storage.updateInterview(interview.id, {
        status: "completed",
        completedAt: new Date(),
        transcript: transcriptText,
      });

      // Update candidate status
      await storage.updateCandidate(interview.candidateId, { status: "analyzed" });

      res.json({ interview, analysis });
    } catch (error) {
      console.error("Error completing video interview:", error);
      res.status(500).json({ error: "Failed to complete interview" });
    }
  });

  return httpServer;
}
