import { 
  type User, 
  type InsertUser,
  type Position,
  type InsertPosition,
  type Candidate,
  type InsertCandidate,
  type Interview,
  type InsertInterview,
  type InterviewMessage,
  type InsertInterviewMessage,
  type VideoAsset,
  type InsertVideoAsset,
  type AnalysisResult,
  type InsertAnalysisResult
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Positions
  getPositions(): Promise<Position[]>;
  getPosition(id: string): Promise<Position | undefined>;
  createPosition(position: InsertPosition): Promise<Position>;
  updatePosition(id: string, position: Partial<InsertPosition>): Promise<Position | undefined>;
  deletePosition(id: string): Promise<boolean>;

  // Candidates
  getCandidates(): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  updateCandidate(id: string, candidate: Partial<InsertCandidate>): Promise<Candidate | undefined>;
  deleteCandidate(id: string): Promise<boolean>;

  // Interviews
  getInterviews(): Promise<Interview[]>;
  getInterview(id: string): Promise<Interview | undefined>;
  createInterview(interview: InsertInterview): Promise<Interview>;
  updateInterview(id: string, interview: Partial<InsertInterview>): Promise<Interview | undefined>;
  deleteInterview(id: string): Promise<boolean>;

  // Interview Messages
  getInterviewMessages(interviewId: string): Promise<InterviewMessage[]>;
  createInterviewMessage(message: InsertInterviewMessage): Promise<InterviewMessage>;

  // Video Assets
  getVideoAssets(): Promise<VideoAsset[]>;
  getVideoAsset(id: string): Promise<VideoAsset | undefined>;
  createVideoAsset(video: InsertVideoAsset): Promise<VideoAsset>;
  updateVideoAsset(id: string, video: Partial<InsertVideoAsset>): Promise<VideoAsset | undefined>;
  deleteVideoAsset(id: string): Promise<boolean>;

  // Analysis Results
  getAnalysisResults(): Promise<AnalysisResult[]>;
  getAnalysisResult(id: string): Promise<AnalysisResult | undefined>;
  getAnalysisResultByCandidate(candidateId: string): Promise<AnalysisResult | undefined>;
  getAnalysisResultByInterview(interviewId: string): Promise<AnalysisResult | undefined>;
  createAnalysisResult(analysis: InsertAnalysisResult): Promise<AnalysisResult>;
  updateAnalysisResult(id: string, analysis: Partial<InsertAnalysisResult>): Promise<AnalysisResult | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private positions: Map<string, Position>;
  private candidates: Map<string, Candidate>;
  private interviews: Map<string, Interview>;
  private interviewMessages: Map<string, InterviewMessage>;
  private videoAssets: Map<string, VideoAsset>;
  private analysisResults: Map<string, AnalysisResult>;

  constructor() {
    this.users = new Map();
    this.positions = new Map();
    this.candidates = new Map();
    this.interviews = new Map();
    this.interviewMessages = new Map();
    this.videoAssets = new Map();
    this.analysisResults = new Map();

    // Seed some demo data
    this.seedDemoData();
  }

  private seedDemoData() {
    // Create demo positions
    const positions: InsertPosition[] = [
      {
        title: "Desarrollador Full Stack",
        department: "Ingeniería",
        description: "Buscamos un desarrollador full stack con experiencia en React y Node.js para unirse a nuestro equipo de producto.",
        requirements: "3+ años de experiencia, React, Node.js, TypeScript, PostgreSQL",
        status: "open"
      },
      {
        title: "Diseñador UX/UI",
        department: "Diseño",
        description: "Diseñador con pasión por crear experiencias de usuario excepcionales.",
        requirements: "Figma, Design Systems, Investigación de usuarios",
        status: "open"
      },
      {
        title: "Product Manager",
        department: "Producto",
        description: "Líder de producto para definir y ejecutar la visión del producto.",
        requirements: "5+ años en gestión de productos digitales",
        status: "open"
      }
    ];

    positions.forEach(pos => this.createPosition(pos));

    // Create demo candidates
    const candidates: InsertCandidate[] = [
      {
        name: "María García",
        email: "maria.garcia@email.com",
        phone: "+52 55 1234 5678",
        status: "pending",
        notes: "Candidata referida por el equipo de ingeniería"
      },
      {
        name: "Carlos Rodríguez",
        email: "carlos.rodriguez@email.com",
        phone: "+52 55 8765 4321",
        status: "screening",
        notes: "Experiencia interesante en startups"
      },
      {
        name: "Ana Martínez",
        email: "ana.martinez@email.com",
        phone: "+52 55 2468 1357",
        status: "interviewing",
        notes: "Perfil técnico muy sólido"
      }
    ];

    candidates.forEach(cand => this.createCandidate(cand));
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Positions
  async getPositions(): Promise<Position[]> {
    return Array.from(this.positions.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getPosition(id: string): Promise<Position | undefined> {
    return this.positions.get(id);
  }

  async createPosition(insertPosition: InsertPosition): Promise<Position> {
    const id = randomUUID();
    const position: Position = {
      ...insertPosition,
      id,
      status: insertPosition.status || "open",
      createdAt: new Date(),
    };
    this.positions.set(id, position);
    return position;
  }

  async updatePosition(id: string, updates: Partial<InsertPosition>): Promise<Position | undefined> {
    const position = this.positions.get(id);
    if (!position) return undefined;
    const updated = { ...position, ...updates };
    this.positions.set(id, updated);
    return updated;
  }

  async deletePosition(id: string): Promise<boolean> {
    return this.positions.delete(id);
  }

  // Candidates
  async getCandidates(): Promise<Candidate[]> {
    return Array.from(this.candidates.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getCandidate(id: string): Promise<Candidate | undefined> {
    return this.candidates.get(id);
  }

  async createCandidate(insertCandidate: InsertCandidate): Promise<Candidate> {
    const id = randomUUID();
    const candidate: Candidate = {
      ...insertCandidate,
      id,
      status: insertCandidate.status || "pending",
      createdAt: new Date(),
    };
    this.candidates.set(id, candidate);
    return candidate;
  }

  async updateCandidate(id: string, updates: Partial<InsertCandidate>): Promise<Candidate | undefined> {
    const candidate = this.candidates.get(id);
    if (!candidate) return undefined;
    const updated = { ...candidate, ...updates };
    this.candidates.set(id, updated);
    return updated;
  }

  async deleteCandidate(id: string): Promise<boolean> {
    return this.candidates.delete(id);
  }

  // Interviews
  async getInterviews(): Promise<Interview[]> {
    return Array.from(this.interviews.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getInterview(id: string): Promise<Interview | undefined> {
    return this.interviews.get(id);
  }

  async createInterview(insertInterview: InsertInterview): Promise<Interview> {
    const id = randomUUID();
    const interview: Interview = {
      ...insertInterview,
      id,
      type: insertInterview.type || "ai_chat",
      status: insertInterview.status || "scheduled",
      scheduledAt: insertInterview.scheduledAt || null,
      completedAt: insertInterview.completedAt || null,
      transcript: insertInterview.transcript || null,
      createdAt: new Date(),
    };
    this.interviews.set(id, interview);
    return interview;
  }

  async updateInterview(id: string, updates: Partial<InsertInterview>): Promise<Interview | undefined> {
    const interview = this.interviews.get(id);
    if (!interview) return undefined;
    const updated = { ...interview, ...updates };
    this.interviews.set(id, updated);
    return updated;
  }

  async deleteInterview(id: string): Promise<boolean> {
    return this.interviews.delete(id);
  }

  // Interview Messages
  async getInterviewMessages(interviewId: string): Promise<InterviewMessage[]> {
    return Array.from(this.interviewMessages.values())
      .filter(msg => msg.interviewId === interviewId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async createInterviewMessage(insertMessage: InsertInterviewMessage): Promise<InterviewMessage> {
    const id = randomUUID();
    const message: InterviewMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.interviewMessages.set(id, message);
    return message;
  }

  // Video Assets
  async getVideoAssets(): Promise<VideoAsset[]> {
    return Array.from(this.videoAssets.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getVideoAsset(id: string): Promise<VideoAsset | undefined> {
    return this.videoAssets.get(id);
  }

  async createVideoAsset(insertVideo: InsertVideoAsset): Promise<VideoAsset> {
    const id = randomUUID();
    const video: VideoAsset = {
      ...insertVideo,
      id,
      status: insertVideo.status || "pending",
      fileUrl: insertVideo.fileUrl || null,
      transcript: insertVideo.transcript || null,
      createdAt: new Date(),
    };
    this.videoAssets.set(id, video);
    return video;
  }

  async updateVideoAsset(id: string, updates: Partial<InsertVideoAsset>): Promise<VideoAsset | undefined> {
    const video = this.videoAssets.get(id);
    if (!video) return undefined;
    const updated = { ...video, ...updates };
    this.videoAssets.set(id, updated);
    return updated;
  }

  async deleteVideoAsset(id: string): Promise<boolean> {
    return this.videoAssets.delete(id);
  }

  // Analysis Results
  async getAnalysisResults(): Promise<AnalysisResult[]> {
    return Array.from(this.analysisResults.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getAnalysisResult(id: string): Promise<AnalysisResult | undefined> {
    return this.analysisResults.get(id);
  }

  async getAnalysisResultByCandidate(candidateId: string): Promise<AnalysisResult | undefined> {
    return Array.from(this.analysisResults.values()).find(
      a => a.candidateId === candidateId
    );
  }

  async getAnalysisResultByInterview(interviewId: string): Promise<AnalysisResult | undefined> {
    return Array.from(this.analysisResults.values()).find(
      a => a.interviewId === interviewId
    );
  }

  async createAnalysisResult(insertAnalysis: InsertAnalysisResult): Promise<AnalysisResult> {
    const id = randomUUID();
    const analysis: AnalysisResult = {
      ...insertAnalysis,
      id,
      communicationScore: insertAnalysis.communicationScore || null,
      technicalScore: insertAnalysis.technicalScore || null,
      culturalFitScore: insertAnalysis.culturalFitScore || null,
      overallScore: insertAnalysis.overallScore || null,
      strengths: insertAnalysis.strengths || null,
      weaknesses: insertAnalysis.weaknesses || null,
      recommendation: insertAnalysis.recommendation || null,
      summary: insertAnalysis.summary || null,
      keyInsights: insertAnalysis.keyInsights || null,
      interviewId: insertAnalysis.interviewId || null,
      videoAssetId: insertAnalysis.videoAssetId || null,
      createdAt: new Date(),
    };
    this.analysisResults.set(id, analysis);
    return analysis;
  }

  async updateAnalysisResult(id: string, updates: Partial<InsertAnalysisResult>): Promise<AnalysisResult | undefined> {
    const analysis = this.analysisResults.get(id);
    if (!analysis) return undefined;
    const updated = { ...analysis, ...updates };
    this.analysisResults.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
